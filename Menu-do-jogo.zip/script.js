var MENU = 0
var img1;
var img2;
var img3;
// IMAGEM DO MENU
function preload() {
  img1 = loadImage('SPACESHIP.png');
  img2 = loadImage('INSTRUÇOES.png');
  img3 = loadImage('CREDITOS.png');
}

function setup() {
  createCanvas(800, 600);
}
// MENU
function draw() {
  print(mouseX, mouseY)
  background(250);
  image(img1, 0, 0, 750, 480);
  fill(0, 0, 0);
  fill(0, 0, 0);
  fill(0, 0, 0);
  textSize(40)
  fill(255);
  text('', 265, 250);
  text('', 250, 406);
  textSize(36);
  text('', 250, 319);
 
   // JOGAR
  if (MENU == 1) {
    background(0, 255, 0)
    fill(0)
    textSize(20)
    if (mouseButton == RIGHT) {
      MENU = 0
    }
  } // INSTRUÇÂO
  if (MENU == 2) {
    background(255, 0, 255)
    image(img2, 0, 0, 750, 480);
    if (mouseButton == RIGHT) {
      MENU = 0
    }
  } // CREDITOS
  if (MENU == 3) {
    background(255, 0, 0)
    image(img3, 0, 0, 750, 480);
        if (mouseButton == RIGHT){
          MENU = 0
        } 
  }
 }// Comando para entrar no menu 

function mouseClicked() {
  if (MENU == 0) {
    if (mouseX < 500 && mouseX > 240) {
      if (mouseY < 210 && mouseY > 180) {
        MENU = 1
      }
      if (mouseY < 485 && mouseY > 290) {
        MENU = 2
      }
      if (mouseY < 535 && mouseY > 350) {
        MENU = 3
      }
    }
  }
}